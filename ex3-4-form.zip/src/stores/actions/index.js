export const createAction = (type , payload) => {
    return {
        type,
        payload
    }
}